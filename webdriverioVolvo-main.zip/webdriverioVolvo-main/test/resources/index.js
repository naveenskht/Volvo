export default{
    browserTitle:'A million more',
    mainHeader:'most controversial',
}